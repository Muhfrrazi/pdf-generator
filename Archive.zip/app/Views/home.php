<!doctype html>
<html lang="id">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>PDF Studio</title>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:wght@600;700&family=Plus+Jakarta+Sans:wght@300;400;500;600&display=swap"
      rel="stylesheet"
    />
    <link rel="stylesheet" href="<?= base_url('assets/style.css') ?>" />
  </head>
  <body>
    <div class="grain" aria-hidden="true"></div>
    <div class="app-shell">
      <header class="topbar">
        <div class="brand">
          <div class="brand-mark">W</div>
          <div>
            <p class="brand-name">PDF Studio</p>
            <p class="brand-sub">PDF toolkit offline untuk tim Anda.</p>
          </div>
        </div>
        <div class="top-meta">
          <span class="meta-chip">Offline mode</span>
          <span class="meta-chip accent">No upload</span>
        </div>
      </header>

      <main class="main">
        <section id="homePage" class="hero">
          <div class="hero-copy">
            <p class="eyebrow">Toolkit PDF offline</p>
            <h1>Semua tool PDF yang Anda butuhkan dalam satu tempat.</h1>
            <p>
              Fokus kerja lebih cepat dengan alur yang ringan, aman, dan tetap 100%
              offline.
            </p>
            <div class="hero-chips">
              <span class="chip">Tanpa upload</span>
              <span class="chip">Cepat & ringan</span>
              <span class="chip">Kontrol penuh</span>
              <span class="chip">Gratis dipakai</span>
            </div>
          </div>
          <div class="hero-grid">
            <button class="tool-card" data-tool="watermark" type="button">
              <div class="tool-card-icon accent">W</div>
              <div>
                <h3>Watermark</h3>
                <p>
                  Tempelkan gambar atau teks di atas PDF dalam hitungan detik.
                  Pilih tipografi, transparansi, dan posisi.
                </p>
              </div>
            </button>
            <button class="tool-card" data-tool="merge" type="button">
              <div class="tool-card-icon warm">M</div>
              <div>
                <h3>Merge PDF</h3>
                <p>
                  Gabungkan PDF sesuai urutan yang Anda inginkan dengan merger
                  paling mudah.
                </p>
              </div>
            </button>
            <button class="tool-card" data-tool="compress" type="button">
              <div class="tool-card-icon cool">C</div>
              <div>
                <h3>Compress PDF</h3>
                <p>
                  Perkecil ukuran file sambil menjaga kualitas PDF setinggi mungkin.
                </p>
              </div>
            </button>
            <button class="tool-card" data-tool="split" type="button">
              <div class="tool-card-icon accent">S</div>
              <div>
                <h3>Split PDF</h3>
                <p>
                  Pisahkan satu halaman atau satu set untuk konversi menjadi file
                  PDF terpisah.
                </p>
              </div>
            </button>
            <button class="tool-card" data-tool="jpg" type="button">
              <div class="tool-card-icon warm">J</div>
              <div>
                <h3>PDF to JPG</h3>
                <p>
                  Ubah tiap halaman PDF menjadi JPG atau ekstrak semua gambar di
                  dalamnya.
                </p>
              </div>
            </button>
          </div>
        </section>

        <section id="toolPage" class="tool-page hidden">
          <div class="workspace">
          <section class="panel controls">
          <div class="tool-heading">
            <button id="backHome" class="back-btn" type="button">Kembali</button>
            <div>
              <p class="eyebrow">Tool terpilih</p>
              <h2 id="toolTitle">Watermark</h2>
              <p id="toolSubtitle" class="note">
                Tempelkan teks atau logo di atas PDF dengan kontrol penuh.
              </p>
            </div>
          </div>

          <div id="sourcePdfSection" class="section">
            <label class="label" for="pdfInput">PDF sumber</label>
            <input id="pdfInput" type="file" accept="application/pdf" />
          </div>

          <div id="watermarkTool" class="tool-section">
            <div class="section">
              <span class="label">Tipe watermark</span>
              <div class="segmented" role="group" aria-label="Tipe watermark">
                <button class="seg-btn active" data-type="text" type="button">Teks</button>
                <button class="seg-btn" data-type="image" type="button">Logo</button>
              </div>
            </div>

            <div id="textControls" class="section">
              <label class="label" for="wmText">Isi teks</label>
              <textarea id="wmText" rows="3"></textarea>
              <p class="note">Gunakan Enter untuk baris baru.</p>

              <div class="grid two">
                <div>
                  <label class="label" for="wmFont">Font</label>
                  <select id="wmFont">
                    <option value="Helvetica">Helvetica</option>
                    <option value="HelveticaBold">Helvetica Bold</option>
                    <option value="TimesRoman">Times Roman</option>
                    <option value="TimesBold">Times Bold</option>
                    <option value="Courier">Courier</option>
                    <option value="CourierBold">Courier Bold</option>
                  </select>
                </div>
                <div>
                  <label class="label" for="wmColor">Warna</label>
                  <input id="wmColor" type="color" value="#6f6f6f" />
                </div>
              </div>

              <div class="grid two">
                <div>
                  <label class="label" for="wmSize">Ukuran</label>
                  <div class="range">
                    <input id="wmSize" type="range" min="12" max="160" value="42" />
                    <span id="wmSizeVal">42px</span>
                  </div>
                </div>
                <div>
                  <label class="label" for="wmOpacity">Opacity</label>
                  <div class="range">
                    <input id="wmOpacity" type="range" min="0" max="100" value="20" />
                    <span id="wmOpacityVal">20%</span>
                  </div>
                </div>
              </div>

              <div class="grid two">
                <div>
                  <label class="label" for="wmRotation">Rotasi</label>
                  <div class="range">
                    <input id="wmRotation" type="range" min="-90" max="90" value="-35" />
                    <span id="wmRotationVal">-35deg</span>
                  </div>
                </div>
                <div>
                  <label class="label" for="wmMode">Mode</label>
                  <select id="wmMode">
                    <option value="repeat">Repeat diagonal</option>
                    <option value="single">Single (bisa digeser)</option>
                  </select>
                </div>
              </div>

              <div class="grid two" id="spacingRow">
                <div>
                  <label class="label" for="wmSpacing">Jarak pola</label>
                  <div class="range">
                    <input id="wmSpacing" type="range" min="120" max="420" value="220" />
                    <span id="wmSpacingVal">220px</span>
                  </div>
                </div>
                <div class="hint-box">
                  <p>Seret pratinjau untuk geser pola repeat.</p>
                </div>
              </div>

              <div id="textSingleHint" class="hint-box">
                <p>Posisi teks default di tengah, bisa digeser di preview.</p>
              </div>
            </div>

            <div id="imageControls" class="section hidden">
              <label class="label" for="imageInput">Logo (PNG/JPG)</label>
              <input id="imageInput" type="file" accept="image/png,image/jpeg" />

              <div class="grid two">
                <div>
                  <label class="label" for="imgWidth">Lebar</label>
                  <div class="range">
                    <input id="imgWidth" type="range" min="60" max="720" value="180" />
                    <span id="imgWidthVal">180px</span>
                  </div>
                </div>
                <div>
                  <label class="label" for="imgOpacity">Opacity</label>
                  <div class="range">
                    <input id="imgOpacity" type="range" min="0" max="100" value="30" />
                    <span id="imgOpacityVal">30%</span>
                  </div>
                </div>
              </div>

              <div class="grid two">
                <div>
                  <label class="label" for="imgRotation">Rotasi</label>
                  <div class="range">
                    <input id="imgRotation" type="range" min="-90" max="90" value="-15" />
                    <span id="imgRotationVal">-15deg</span>
                  </div>
                </div>
                <div>
                  <label class="label" for="imgScope">Terapkan di</label>
                  <select id="imgScope">
                    <option value="all">Semua halaman</option>
                    <option value="first">Halaman pertama saja</option>
                  </select>
                </div>
              </div>

              <div class="hint-box">
                <p>Logo dapat digeser di pratinjau.</p>
              </div>
            </div>

            <div class="section actions">
              <button id="applyBtn" class="primary" type="button" disabled>
                Export PDF
              </button>
              <button id="resetBtn" type="button" disabled>Reset posisi</button>
            </div>
          </div>

          <div id="compressTool" class="tool-section hidden">
            <div class="section">
              <label class="label" for="compressMode">Mode kompresi</label>
              <select id="compressMode">
                <option value="lossless">Lossless (cepat)</option>
                <option value="rasterize">Rasterize (lebih kecil)</option>
              </select>
            </div>

            <div id="compressQualityRow" class="section">
              <label class="label" for="compressQuality">Kualitas JPG</label>
              <div class="range">
                <input id="compressQuality" type="range" min="40" max="100" value="75" />
                <span id="compressQualityVal">75%</span>
              </div>
            </div>

            <div id="compressScaleRow" class="section">
              <label class="label" for="compressScale">Skala render</label>
              <div class="range">
                <input id="compressScale" type="range" min="0.5" max="2" step="0.1" value="1" />
                <span id="compressScaleVal">1.0x</span>
              </div>
            </div>

            <div class="section actions">
              <button id="compressBtn" class="primary" type="button" disabled>
                Compress PDF
              </button>
            </div>

            <p class="note">
              Mode rasterize akan mengubah teks menjadi gambar agar ukuran lebih kecil.
            </p>
          </div>

          <div id="mergeTool" class="tool-section hidden">
            <div class="section">
              <label class="label" for="mergeInput">PDF untuk digabung</label>
              <input id="mergeInput" type="file" accept="application/pdf" multiple />
            </div>

            <div id="mergeList" class="file-list"></div>

            <div class="section actions">
              <button id="mergeBtn" class="primary" type="button" disabled>
                Merge PDF
              </button>
            </div>
          </div>

          <div id="splitTool" class="tool-section hidden">
            <div class="section">
              <label class="label" for="splitMode">Mode split</label>
              <select id="splitMode">
                <option value="all">Per halaman</option>
                <option value="range">Range halaman</option>
              </select>
            </div>

            <div id="splitRangeRow" class="grid two hidden">
              <div>
                <label class="label" for="splitStart">Mulai</label>
                <input id="splitStart" type="number" min="1" value="1" />
              </div>
              <div>
                <label class="label" for="splitEnd">Sampai</label>
                <input id="splitEnd" type="number" min="1" value="1" />
              </div>
            </div>

            <div class="section actions">
              <button id="splitBtn" class="primary" type="button" disabled>
                Split PDF
              </button>
            </div>

            <p class="note">Mode per halaman akan mengunduh ZIP.</p>
          </div>

          <div id="jpgTool" class="tool-section hidden">
            <div class="section">
              <label class="label" for="jpgScope">Halaman</label>
              <select id="jpgScope">
                <option value="all">Semua halaman</option>
                <option value="current">Halaman sekarang</option>
              </select>
            </div>

            <div class="grid two">
              <div>
                <label class="label" for="jpgQuality">Kualitas JPG</label>
                <div class="range">
                  <input id="jpgQuality" type="range" min="40" max="100" value="90" />
                  <span id="jpgQualityVal">90%</span>
                </div>
              </div>
              <div>
                <label class="label" for="jpgScale">Skala render</label>
                <div class="range">
                  <input id="jpgScale" type="range" min="0.5" max="2" step="0.1" value="1" />
                  <span id="jpgScaleVal">1.0x</span>
                </div>
              </div>
            </div>

            <div class="section actions">
              <button id="jpgBtn" class="primary" type="button" disabled>
                Export JPG
              </button>
            </div>
          </div>

          <div id="toolStatus" class="section status hidden">
            <span id="statusText"></span>
          </div>

          <div class="section note">
            <p>
              Semua proses berjalan di browser. PDF dan logo Anda tidak dikirim ke
              server.
            </p>
          </div>
          </section>

          <section class="panel preview">
          <div class="preview-head">
            <div>
              <h2>Preview</h2>
              <p class="preview-sub">Pantau posisi watermark dan hasil output.</p>
            </div>
            <div class="page-controls">
              <button id="prevPage" type="button" disabled>Prev</button>
              <span id="pageIndicator">Page 0 / 0</span>
              <button id="nextPage" type="button" disabled>Next</button>
            </div>
          </div>
          <div id="previewWrap" class="preview-wrap">
            <canvas id="pdfCanvas"></canvas>
            <canvas id="patternCanvas" class="overlay hidden"></canvas>
            <div id="watermarkOverlay" class="overlay watermark hidden">
              <div id="wmTextOverlay" class="wm-text"></div>
              <img id="wmImageOverlay" class="wm-image hidden" alt="Watermark" />
            </div>
            <div id="emptyState" class="empty">
              <p>Upload PDF untuk mulai.</p>
            </div>
          </div>
          </section>
          </div>
        </section>
      </main>
      <footer class="footer">
        <span>Razi</span>
        <span>v1.0.0</span>
      </footer>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdf-lib/1.17.1/pdf-lib.min.js"></script>
    <script src="<?= base_url('assets/app.js') ?>"></script>
  </body>
</html>
